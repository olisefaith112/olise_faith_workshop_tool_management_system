# Workshop Tool Inventory and Maintenance Management System

**Course:** CTE213  
**Student:** Olise Faith Juliet  
**Matric Number:** F/ND/24/3450073  
**Programme:** ND II Mechatronics Engineering  
**Institution:** Yaba College of Technology (YABATECH)

## 1. Project overview
This Python program helps a technical workshop keep track of tools and equipment. It records tool quantities, manages issuing and returns, tracks tool condition, and highlights stock and maintenance problems.

This project is different from a water-tank monitoring system and an energy-cost estimation system. Its main focus is **workshop inventory control and preventive maintenance**.

## 2. Problem statement
Workshops may lose track of tools when items are issued and returned manually. Tools can also become unavailable or unsafe when low stock, damage, or overdue servicing is not noticed early. This system provides a simple digital record to help reduce these problems.

## 3. Objectives
- Register tools with unique identification numbers.
- Record tool categories and quantities.
- Issue tools and record returns.
- Prevent issuing more units than are available.
- Track tool condition and service dates.
- Alert the user when stock is low or maintenance is due.
- Produce a usage summary and export inventory data to CSV.

## 4. Main features
1. **Tool registration:** Add a new tool with a unique ID.
2. **Issue and return:** Update available quantities when tools leave or return to the workshop.
3. **Condition monitoring:** Mark tools as Good, Fair, or Needs Repair.
4. **Maintenance tracking:** Record service dates and flag tools that have reached the 90-day service interval.
5. **Low-stock alert:** Flag tools with two or fewer available units.
6. **Usage report:** Calculate total, available, and issued units and identify the most frequently issued tool.
7. **CSV export:** Save the inventory report for record keeping.

## 5. Python concepts demonstrated
- **Functions:** Separate functions handle registration, issuing, returns, alerts, reporting, and other tasks.
- **Lists:** A list stores the workshop's tool records.
- **Loops:** `while` loops keep the menu running and validate input; `for` loops process tool records.
- **Conditional statements:** `if`, `elif`, and `else` statements control menu options and system alerts.
- **Input validation:** The program rejects blank entries, invalid menu options, non-numeric quantities, and quantities outside the available range.
- **Original feature:** The combined low-stock, service-due, and repair-alert system supports preventive workshop maintenance.

## 6. Requirements
- Python 3.8 or later
- No external Python packages are required.

## 7. How to run
1. Download or clone this repository.
2. Open a terminal or command prompt in the project folder.
3. Run:

   ```bash
   python workshop_tool_management.py
   ```

4. Select an option from the menu and follow the prompts.

## 8. Sample test scenarios
- Try adding a tool with an ID that already exists. The program should reject it.
- Try issuing more units than are available. The program should reject the quantity.
- Issue a tool, then return some or all of the issued units.
- Change a tool's condition to `Needs Repair` and view workshop alerts.
- Record maintenance and confirm that the service date is updated.
- Export the inventory and check the generated CSV file.

## 9. Limitations and future improvements
This version stores records in memory while the program is running. A future version could use a database, add user login, record each borrower's expected return date, and provide a graphical user interface.

## 10. Conclusion
The Workshop Tool Inventory and Maintenance Management System demonstrates how Python can be applied to a real workshop management problem. It combines inventory control, input validation, reporting, and preventive maintenance alerts in one menu-driven application.
