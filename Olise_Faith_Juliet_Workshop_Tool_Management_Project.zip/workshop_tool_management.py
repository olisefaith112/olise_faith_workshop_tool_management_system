"""
CTE213 - Workshop Tool Inventory and Maintenance Management System
Student: Olise Faith Juliet
Matric Number: F/ND/24/3450073
Programme: ND II Mechatronics Engineering
Institution: Yaba College of Technology (YABATECH)

A menu-driven Python application for recording workshop tools, issuing and
returning tools, monitoring stock levels, and tracking maintenance.
"""

from datetime import date, datetime, timedelta

LOW_STOCK_LIMIT = 2
MAINTENANCE_INTERVAL_DAYS = 90

tools = [
    {
        "id": "T001", "name": "Digital Multimeter", "category": "Electrical",
        "quantity": 5, "available": 5, "condition": "Good",
        "last_service": date.today() - timedelta(days=25), "uses": 0
    },
    {
        "id": "T002", "name": "Soldering Iron", "category": "Electrical",
        "quantity": 4, "available": 4, "condition": "Good",
        "last_service": date.today() - timedelta(days=105), "uses": 0
    },
    {
        "id": "T003", "name": "Spanner Set", "category": "Mechanical",
        "quantity": 3, "available": 3, "condition": "Fair",
        "last_service": date.today() - timedelta(days=40), "uses": 0
    },
]


def read_non_empty(prompt):
    """Accept text input and reject blank entries."""
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("Input cannot be empty. Please try again.")


def read_positive_int(prompt, maximum=None):
    """Validate a positive whole-number input."""
    while True:
        try:
            value = int(input(prompt))
            if value <= 0 or (maximum is not None and value > maximum):
                print("Enter a valid positive quantity.")
                continue
            return value
        except ValueError:
            print("Please enter a whole number.")


def find_tool(tool_id):
    """Return a tool record by its unique ID, or None if it does not exist."""
    for tool in tools:
        if tool["id"].lower() == tool_id.lower():
            return tool
    return None


def display_tools():
    """Display all tools and their current availability."""
    if not tools:
        print("\nNo tools have been registered.")
        return

    print("\n" + "-" * 88)
    print(f"{'ID':<7}{'TOOL':<24}{'CATEGORY':<16}{'TOTAL':>7}{'AVAILABLE':>12}{'CONDITION':>12}")
    print("-" * 88)
    for tool in tools:
        print(f"{tool['id']:<7}{tool['name']:<24}{tool['category']:<16}"
              f"{tool['quantity']:>7}{tool['available']:>12}{tool['condition']:>12}")
    print("-" * 88)


def add_tool():
    """Register a new tool after validating its details."""
    print("\nREGISTER A NEW TOOL")
    tool_id = read_non_empty("Enter a unique tool ID (e.g. T004): ").upper()
    if find_tool(tool_id):
        print("That tool ID already exists.")
        return

    name = read_non_empty("Tool name: ")
    category = read_non_empty("Category (Electrical/Mechanical/etc.): ")
    quantity = read_positive_int("Quantity: ")
    tools.append({
        "id": tool_id, "name": name, "category": category,
        "quantity": quantity, "available": quantity, "condition": "Good",
        "last_service": date.today(), "uses": 0
    })
    print(f"{name} has been added successfully.")


def issue_tool():
    """Issue tools to a student or workshop user."""
    print("\nISSUE A TOOL")
    tool_id = read_non_empty("Enter tool ID: ")
    tool = find_tool(tool_id)
    if tool is None:
        print("Tool ID not found.")
        return
    if tool["available"] == 0:
        print("No unit is currently available for issue.")
        return

    borrower = read_non_empty("Borrower's name: ")
    quantity = read_positive_int("Quantity to issue: ", tool["available"])
    tool["available"] -= quantity
    tool["uses"] += quantity
    print(f"{quantity} unit(s) of {tool['name']} issued to {borrower}.")
    print(f"Units currently available: {tool['available']}")


def return_tool():
    """Record returned tools and prevent quantities exceeding stock."""
    print("\nRETURN A TOOL")
    tool_id = read_non_empty("Enter tool ID: ")
    tool = find_tool(tool_id)
    if tool is None:
        print("Tool ID not found.")
        return

    outstanding = tool["quantity"] - tool["available"]
    if outstanding == 0:
        print("There are no outstanding units of this tool.")
        return

    quantity = read_positive_int("Quantity being returned: ", outstanding)
    tool["available"] += quantity
    print(f"{quantity} unit(s) of {tool['name']} returned successfully.")


def update_condition():
    """Update the recorded physical condition of a tool."""
    print("\nUPDATE TOOL CONDITION")
    tool = find_tool(read_non_empty("Enter tool ID: "))
    if tool is None:
        print("Tool ID not found.")
        return

    print("1. Good\n2. Fair\n3. Needs Repair")
    choices = {"1": "Good", "2": "Fair", "3": "Needs Repair"}
    choice = input("Select condition: ").strip()
    if choice not in choices:
        print("Invalid condition selection.")
        return
    tool["condition"] = choices[choice]
    print(f"{tool['name']} condition updated to: {tool['condition']}")


def record_maintenance():
    """Record servicing and reset the maintenance timer."""
    print("\nRECORD MAINTENANCE")
    tool = find_tool(read_non_empty("Enter tool ID: "))
    if tool is None:
        print("Tool ID not found.")
        return
    tool["last_service"] = date.today()
    tool["condition"] = "Good"
    print(f"Maintenance recorded for {tool['name']} on {date.today()}.")


def show_alerts():
    """Identify low stock, overdue maintenance, and tools needing repair."""
    print("\nWORKSHOP ALERTS")
    alerts_found = False
    for tool in tools:
        if tool["available"] <= LOW_STOCK_LIMIT:
            print(f"LOW STOCK: {tool['name']} has {tool['available']} unit(s) available.")
            alerts_found = True

        days_since_service = (date.today() - tool["last_service"]).days
        if days_since_service >= MAINTENANCE_INTERVAL_DAYS:
            print(f"SERVICE DUE: {tool['name']} was last serviced "
                  f"{days_since_service} days ago.")
            alerts_found = True

        if tool["condition"] == "Needs Repair":
            print(f"REPAIR ALERT: {tool['name']} is marked as needing repair.")
            alerts_found = True

    if not alerts_found:
        print("No alerts. All recorded tools are within the set limits.")


def show_usage_report():
    """Summarise inventory utilisation and identify the most-used tool."""
    print("\nTOOL USAGE REPORT")
    total_units = sum(tool["quantity"] for tool in tools)
    available_units = sum(tool["available"] for tool in tools)
    issued_units = total_units - available_units
    print(f"Different tool types: {len(tools)}")
    print(f"Total tool units: {total_units}")
    print(f"Available units: {available_units}")
    print(f"Currently issued units: {issued_units}")

    if tools:
        most_used = max(tools, key=lambda item: item["uses"])
        print(f"Most frequently issued tool: {most_used['name']} "
              f"({most_used['uses']} unit issue(s) recorded)")

    if total_units:
        utilisation = (issued_units / total_units) * 100
        print(f"Current issue rate: {utilisation:.1f}%")


def export_report():
    """Save the current inventory to a date-stamped CSV file."""
    import csv
    filename = f"workshop_tool_report_{date.today().isoformat()}.csv"
    fields = ["id", "name", "category", "quantity", "available",
              "condition", "last_service", "uses"]
    try:
        with open(filename, "w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            for tool in tools:
                row = tool.copy()
                row["last_service"] = row["last_service"].isoformat()
                writer.writerow(row)
        print(f"Report exported successfully as {filename}.")
    except OSError as error:
        print(f"Could not save report: {error}")


def main():
    """Run the main menu until the user chooses to exit."""
    print("=" * 58)
    print(" WORKSHOP TOOL INVENTORY AND MAINTENANCE SYSTEM")
    print(" Student: Olise Faith Juliet")
    print(" Matric No.: F/ND/24/3450073")
    print("=" * 58)

    while True:
        print("\nMAIN MENU")
        print("1. View all tools")
        print("2. Add a new tool")
        print("3. Issue a tool")
        print("4. Return a tool")
        print("5. Update tool condition")
        print("6. Record maintenance")
        print("7. View workshop alerts")
        print("8. View usage report")
        print("9. Export inventory report to CSV")
        print("0. Exit")

        choice = input("Choose an option: ").strip()
        if choice == "1":
            display_tools()
        elif choice == "2":
            add_tool()
        elif choice == "3":
            issue_tool()
        elif choice == "4":
            return_tool()
        elif choice == "5":
            update_condition()
        elif choice == "6":
            record_maintenance()
        elif choice == "7":
            show_alerts()
        elif choice == "8":
            show_usage_report()
        elif choice == "9":
            export_report()
        elif choice == "0":
            print("Thank you for using the Workshop Tool Management System.")
            break
        else:
            print("Invalid option. Select a number from the menu.")


if __name__ == "__main__":
    main()
